INSERT INTO lookup_unitofmeasure (UnitOfMeasure, UnitOfMeasureText) VALUES ('cup', 'cup');
INSERT INTO lookup_unitofmeasure (UnitOfMeasure, UnitOfMeasureText) VALUES ('g', 'gram');
INSERT INTO lookup_unitofmeasure (UnitOfMeasure, UnitOfMeasureText) VALUES ('lbs', 'pound');
INSERT INTO lookup_unitofmeasure (UnitOfMeasure, UnitOfMeasureText) VALUES ('oz', 'ounce');
INSERT INTO lookup_unitofmeasure (UnitOfMeasure, UnitOfMeasureText) VALUES ('qt', 'quart');
INSERT INTO lookup_unitofmeasure (UnitOfMeasure, UnitOfMeasureText) VALUES ('tbsp', 'tablespoon');
INSERT INTO lookup_unitofmeasure (UnitOfMeasure, UnitOfMeasureText) VALUES ('tsp', 'teaspoon');
