CREATE PROCEDURE `Lookup_Select_Categories`()
BEGIN
	SELECT
		CategoryCode,
		CategoryName
	FROM
		Lookup_CategoryList AS CL
	ORDER BY
		CategoryName,
		CategoryCode;
END