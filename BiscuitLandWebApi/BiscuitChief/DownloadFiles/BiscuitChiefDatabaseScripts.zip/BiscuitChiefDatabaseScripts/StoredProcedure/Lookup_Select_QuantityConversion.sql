CREATE PROCEDURE `Lookup_Select_QuantityConversion`()
BEGIN
	SELECT *
	FROM
		Lookup_QuantityConversion
	ORDER BY
		QuantityDecimal;
END