CREATE PROCEDURE `Lookup_Select_SiteSetting`(
	pSettingCode varchar(20)
)
BEGIN
	SELECT SettingValue FROM Lookup_SiteSettings WHERE SettingCode = pSettingCode;
END