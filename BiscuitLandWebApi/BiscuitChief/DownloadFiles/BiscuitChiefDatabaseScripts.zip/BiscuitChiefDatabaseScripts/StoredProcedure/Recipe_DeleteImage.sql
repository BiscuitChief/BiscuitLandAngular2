DELIMITER $$
CREATE PROCEDURE `Recipe_DeleteImage`(
	pRecipeID varchar(36),
	pImageName varchar(30)
)
BEGIN
	DECLARE pRecipeBinID binary(16);
	SET pRecipeBinID = uuid_to_bin(pRecipeID);

	DELETE FROM Recipe_Images WHERE RecipeID = pRecipeBinID AND ImageName = pImageName;
END$$
DELIMITER ;
