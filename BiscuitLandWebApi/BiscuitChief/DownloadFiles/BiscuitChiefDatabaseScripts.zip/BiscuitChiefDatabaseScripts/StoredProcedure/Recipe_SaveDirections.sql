CREATE PROCEDURE `Recipe_SaveDirections`(
	pDirectionID int,
	pRecipeID varchar(36),
	pSortOrder int,
	pDirectionText longtext,
	pDisplayType varchar(10),
	Out pDirectionIDOut int
)
BEGIN

	DECLARE pRecipeBinID binary(16);
	SET pRecipeBinID = uuid_to_bin(pRecipeID);

	SET pDisplayType = IFNULL(NULLIF(pDisplayType, ''), 'DIR');
	SET pDirectionIDOut = pDirectionID;

	IF IFNULL(@DirectionID, 0) > 0 AND EXISTS(SELECT DirectionID FROM Recipe_Directions WHERE DirectionID = pDirectionID)
	THEN
		UPDATE Recipe_Directions
		SET
			RecipeID = pRecipeBinID,
			SortOrder = pSortOrder,
			DirectionText = pDirectionText,
			DisplayType = pDisplayType
		WHERE
			DirectionID = pDirectionID;
	ELSE
		INSERT INTO Recipe_Directions
		(
			RecipeID,
			SortOrder,
			DirectionText,
			DisplayType
		)
		SELECT
			pRecipeBinID AS RecipeID,
			pSortOrder AS SortOrder,
			pDirectionText AS DirectionText,
			pDisplayType AS DisplayType;

		SET pDirectionIDOut = LAST_INSERT_ID();
	END IF;
	
END