DELIMITER $$
CREATE PROCEDURE `Recipe_SaveImage`(
	pRecipeID varchar(36),
	pImageName varchar(30),
	pIsPrimary tinyint,
	pSortOrder int
)
BEGIN

	DECLARE pRecipeBinID binary(16);
	SET pRecipeBinID = uuid_to_bin(pRecipeID);

	IF EXISTS(SELECT RecipeID FROM Recipe_Images WHERE RecipeID = pRecipeBinID AND ImageName = pImageName)
	THEN
		UPDATE Recipe_Images
		SET IsPrimary = pIsPrimary,
			SortOrder = pSortOrder
		WHERE
			RecipeID = pRecipeBinID
			AND ImageName = pImageName;
	ELSE
		INSERT INTO Recipe_Images
		(
			RecipeID,
			ImageName,
			IsPrimary,
			SortOrder
		)
		VALUES
		(
			pRecipeBinID,
			pImageName,
			pIsPrimary,
			pSortOrder
		);
	END IF;

END$$
DELIMITER ;
