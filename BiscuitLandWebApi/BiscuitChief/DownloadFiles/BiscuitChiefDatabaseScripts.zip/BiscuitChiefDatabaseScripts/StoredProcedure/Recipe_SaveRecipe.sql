CREATE PROCEDURE `Recipe_SaveRecipe`(
	pTitle varchar(300),
	pDescription longtext,
	In pRecipeID varchar(36),
	Out pRecipeIDOut varchar(36)
)
BEGIN

	DECLARE pRecipeBinID binary(16);
	SET pRecipeBinID = uuid_to_bin(pRecipeID);

	IF IFNULL(pRecipeID, '') <> '' AND EXISTS(SELECT RecipeID FROM Recipe_Recipes WHERE RecipeID = pRecipeBinID)
	THEN

		UPDATE Recipe_Recipes
		SET
			Title = pTitle,
			Description = pDescription
		WHERE
			RecipeID = pRecipeBinID;
	ELSE
		SET pRecipeBinID = uuid_to_bin(UUID());

		INSERT INTO Recipe_Recipes
		(
			RecipeID,
			Title,
			Description
		)
		SELECT
			pRecipeBinID as RecipeID,
			pTitle as Title,
			pDescription as Description;
	END IF;
	
	SET pRecipeIDOut = uuid_from_bin(pRecipeBinID);


END