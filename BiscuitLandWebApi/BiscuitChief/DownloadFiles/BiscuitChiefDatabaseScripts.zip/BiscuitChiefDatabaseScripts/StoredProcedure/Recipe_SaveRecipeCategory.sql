CREATE PROCEDURE `Recipe_SaveRecipeCategory`(
	pRecipeID varchar(36),
	pCategoryCode varchar(20)
)
BEGIN

	DECLARE pRecipeBinID binary(16);
	SET pRecipeBinID = uuid_to_bin(pRecipeID);

	IF NOT EXISTS(SELECT RecipeID FROM Recipe_Categories WHERE RecipeID = pRecipeBinID AND CategoryCode = pCategoryCode)
	THEN
		INSERT INTO Recipe_Categories
		(
			RecipeID,
			CategoryCode
		)
		VALUES
		(
			pRecipeBinID,
			pCategoryCode
		);
	END IF;

END