CREATE PROCEDURE `Recipe_Select_Recipe`(
	pRecipeID varchar(36)
)
BEGIN
	DECLARE pRecipeBinID binary(16);
	SET pRecipeBinID = uuid_to_bin(pRecipeID);

	SELECT
		uuid_from_bin(R.RecipeID) AS RecipeID,
		R.Title,
		R.Description
	FROM
		Recipe_Recipes AS R
	WHERE
		R.RecipeID = pRecipeBinID;
END