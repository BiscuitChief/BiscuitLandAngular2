CREATE PROCEDURE `Recipe_Select_RecipeDirections`(
	pRecipeID varchar(36)
)
BEGIN
	DECLARE pRecipeBinID binary(16);
	SET pRecipeBinID = uuid_to_bin(pRecipeID);

	SELECT
		DIR.DirectionID,
		DIR.DirectionText,
		DIR.DisplayType,
		uuid_from_bin(DIR.RecipeID) AS RecipeID,
		DIR.SortOrder
	FROM
		Recipe_Directions AS DIR
	WHERE
		DIR.RecipeID = pRecipeBinID
	ORDER BY
		DIR.SortOrder,
		DIR.DirectionID;
END