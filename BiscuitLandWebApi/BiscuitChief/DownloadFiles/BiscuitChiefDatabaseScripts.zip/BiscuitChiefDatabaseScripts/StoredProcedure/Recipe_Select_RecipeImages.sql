CREATE PROCEDURE `Recipe_Select_RecipeImages`(
	pRecipeID varchar(36)
)
BEGIN
	DECLARE pRecipeBinID binary(16);
	SET pRecipeBinID = uuid_to_bin(pRecipeID);

	SELECT
		uuid_from_bin(IMG.RecipeID) AS RecipeID,
		IMG.ImageName,
		IMG.IsPrimary,
		IMG.SortOrder
	FROM
		Recipe_Images AS IMG
	WHERE
		IMG.RecipeID = pRecipeBinID
	ORDER BY
		IMG.SortOrder,
		IMG.ImageName;
END