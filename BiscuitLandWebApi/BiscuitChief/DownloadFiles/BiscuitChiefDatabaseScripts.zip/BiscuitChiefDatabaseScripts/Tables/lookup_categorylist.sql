CREATE TABLE `lookup_categorylist` (
  `CategoryCode` varchar(20) NOT NULL,
  `CategoryName` varchar(50) NOT NULL,
  PRIMARY KEY (`CategoryCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1