CREATE TABLE `lookup_quantityconversion` (
  `QuantityDecimal` decimal(10,5) NOT NULL,
  `QuantityDisplay` varchar(20) NOT NULL,
  PRIMARY KEY (`QuantityDecimal`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1