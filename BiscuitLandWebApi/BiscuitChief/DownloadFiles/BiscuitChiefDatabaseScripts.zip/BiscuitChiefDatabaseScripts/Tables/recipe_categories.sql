CREATE TABLE `recipe_categories` (
  `RecipeID` binary(16) NOT NULL,
  `CategoryCode` varchar(20) NOT NULL,
  PRIMARY KEY (`RecipeID`,`CategoryCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1