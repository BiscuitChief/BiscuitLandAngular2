CREATE TABLE `recipe_directions` (
  `DirectionID` int(11) NOT NULL AUTO_INCREMENT,
  `RecipeID` binary(16) NOT NULL,
  `SortOrder` int(11) NOT NULL DEFAULT '0',
  `DirectionText` longtext NOT NULL,
  `DisplayType` varchar(10) NOT NULL DEFAULT 'DIR',
  PRIMARY KEY (`DirectionID`)
) ENGINE=MyISAM AUTO_INCREMENT=519 DEFAULT CHARSET=latin1