CREATE TABLE `recipe_images` (
  `RecipeID` binary(16) NOT NULL,
  `ImageName` varchar(30) NOT NULL,
  `SortOrder` int(11) NOT NULL DEFAULT '0',
  `IsPrimary` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`RecipeID`,`ImageName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1